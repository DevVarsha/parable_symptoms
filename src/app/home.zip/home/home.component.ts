import { Component, OnInit } from '@angular/core';
declare var $: any;
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  showMap:boolean=false;
  constructor() { }
  openNav() {
 
   $("#mySidenav").width('250')
 }
 
  closeNav() {
   $("#mySidenav").width('')
 }

  ngOnInit(): void {
   
  }
  changeStatus($element:any){
    this.showMap=false;
    $element.scrollIntoView({behavior: "smooth", block: "start", inline: "nearest"});
  }
  clickData($element:any){
    this.showMap=true; 
    this.scrollToElement($element)
  }
  scrollToElement($element:any): void { 
    console.log($element);
    $element.scrollIntoView({behavior: "smooth", block: "start", inline: "nearest"});
  }
  
 }
